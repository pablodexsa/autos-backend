import { IsNumber, IsPositive, IsDateString, IsOptional, IsString } from 'class-validator';

export class CreateInstallmentPaymentDto {
  @IsNumber({}, { message: 'El ID de la cuota debe ser un n�mero' })
  installmentId: number;

  @IsNumber({}, { message: 'El monto debe ser un n�mero' })
  @IsPositive({ message: 'El monto debe ser positivo' })
  amount: number;

  @IsDateString({}, { message: 'La fecha de pago debe tener un formato v�lido' })
  paymentDate: string;

  @IsOptional()
  @IsString({ message: 'El nombre del archivo debe ser un texto v�lido' })
  receiptPath?: string;
}
